#!/bin/bash
# ==========================================
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
# ==========================================
clear
echo -e ""
echo -e "Starting Restart All Service"
sleep 2
systemctl stop ws-tls
systemctl start sslh
systemctl restart sslh
/etc/init.d/sslh start
/etc/init.d/sslh restart
systemctl restart ssrmu
systemctl restart ws-tls
systemctl restart ws-nontls
systemctl restart xray.service
if systemctl is-active --quiet shadowsocks-libev.service; then
  systemctl restart shadowsocks-libev.service
fi
systemctl restart xl2tpd
systemctl restart pptpd
systemctl restart ipsec
systemctl restart accel-ppp
systemctl restart ws-ovpn
systemctl restart wg-quick@wg0
systemctl restart ssh-ohp
systemctl restart dropbear-ohp
systemctl restart openvpn-ohp
systemctl restart trojan-go
/etc/init.d/ssrmu restart
/etc/init.d/ssh restart
/etc/init.d/dropbear restart
/etc/init.d/sslh restart
/etc/init.d/stunnel5 restart
/etc/init.d/stunnel4 restart
/etc/init.d/openvpn restart
/etc/init.d/fail2ban restart
/etc/init.d/cron restart
/etc/init.d/nginx restart
/etc/init.d/squid restart
if [[ -x /usr/bin/ssh-one-game-network ]]; then
  /usr/bin/ssh-one-game-network restart || echo "Could not restart the BadVPN UDP gateway; run ssh-one-game-network status." >&2
fi
echo -e "Restart All Services Successfully"
